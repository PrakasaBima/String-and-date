package stirngdate;

public interface Supermart {
    public void CetakBill();
}
